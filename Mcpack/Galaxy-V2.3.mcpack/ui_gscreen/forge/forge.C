// ████████╗     █████╗   ██╗       █████╗   ██╗     ██   ██      ██║
// ██╔═════╝    ██╔══██╗  ██║      ██╔══██╗    ██╗ ██╝    ██╗     ██║
// ██║  ██████╗ ███████║  ██║      ███████║      ██╝        ██╗ ██╔═╝
// ██║    ██╔═╝ ██╔══██║  ██║      ██╔══██║    ██╝ ██╗        ██╔═╝
// █████████║   ██║  ██║  ███████╗ ██║  ██║  ██╔╝    ██╗      ██║
// ╚════════╝   ╚═╝  ╚═╝  ╚══════╝ ╚═╝  ╚═╝  ╚═╝     ╚═╝      ╚═╝

//forge is a file to easy programs read
{
  "namespace": "forge_janger_C_UTF-8",
  
//set up //
 
 "setup": {
 "uuid"; "8161c4d6-980a-11ec-b909-0242ac120002, 8161c788-980a-11ec-b909-0242ac120002, 8161c8d2-980a-11ec-b909-0242ac120002, 8161ca12-980a-11ec-b909-0242ac120002", 
 "versionforge": 7.0,
 "versionres": 9.0,
 "versionbeh": 9.0,
 "versiondev": 7.0,
 "forgeset": 4,
 "resourcesmax": 12,
 "forgemax": 12,
 "reload": "true",
 "crash": true,
 "refrashtime": 60S,
 "refrashframeratebelow": 144hz,
 "norefrashif": below25fpsgame or ingame,
 "reset": "false",
 "deletresources": "false",
 "cache": "true", //you can't use false//
 "cachemaxdata": 50KB
 },

//delete this for no cache ↓//
   
 "cache": {
 "generate_on": "forge_resources/cache",
 },
 "force","used": "true": {
 "type": "force_janger",
 "cache": "cache",
 "files": [
 "setnames": (
 "use": "0 = off" "1 = on"),
 "1": 1,
 "2": 1,
 "3": 1,
 "4": 1,
 "5": 1,
 "6": 1,
 "7": 1,
 "8": 1,
 "9": 1,
 "10": 1,
 "11": 1,
 "12": 1,
  ]
 },

//↑//
 
//resources//
 "resources": {
 "locate": "forge_resources/$files"
 "folders": {
 "names": (
 "files.set": "$files = 1" "$nofiles = 0")
 "file1": 1,
 "file2": 1,
 "file3": 1,
 "file4": 1,
 "file5": 1,
 "file6": 1,
 "file7": 1,
 "file8": 1,
 "file9": 1,
 "file10": 1,
 "file11": 1,
 "file12": 1
  }
 },

  "intervariables": { [
 "createV.b": in =  screens/all,
 "createV.b": at =  assets/all,
 "createV.b": ac =  additional_complements/all,
 "createV.c": in =  textures/all
  ] },
 
 "location": {
 "ui_gscreen/in/resources/$file1",
 "ui_gscreen/in/resources/$file2",
 "ui_gscreen/in/resources/$file3",
 "ui_gscreen/in/resources/$file4",
 "ui_gscreen/in/resources/$file5",
 "ui_gscreen/in/resources/$file6",
 "ui_gscreen/at/resources/$file7",
 "ui_gscreen/at/resources/$file8",
 "ui_gscreen/at/resources/$file9",
 "ui_gscreen/at/resources/$file10",
 "ui_gscreen/at/resources/$file11",
 "ui_gscreen/ac/resources/$file12"
 },
 
 "forge_defs": {
 [locationFiles]: {
 Name=storage: [front]
 Name=emuleted: [front]
 Name=0:[front]
 Name=games: [front]
 Name=com.mojang: [front]
 Name=resources_pack: [front]
 [{Name=Folder}]: [front]
   if
 Name=@LocalUser: [front]
 Name=AppData: [front]
 Name=Local:[front]
 Name=Packages: [front]
 Name=#Locate@til+.MinecraftUWP_+til: [front]
 Name=LocalState: [front]
 Name=games: [front]
 Name=com.mojang: [front]
 Name=resource_packs: [front]
 [{Name=Folder}]: [front]
 }
 "ui_gscreen/forge/forge.C",
 "cache:screens"
 "cache:assets"
   if
 Forge== Crash And Create ForgeCrashLog in @windowsTemp@
 Forge== Crash And Create ForgeCrashLog in @macOSTemp@
   or 
 Forge== Crash And Create FrogeCrashLog in @androidTemp@
 Forge== Crash And Create FrogeCrashLog in @iosTemp@
 }
}